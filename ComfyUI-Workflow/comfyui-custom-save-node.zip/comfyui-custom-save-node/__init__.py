from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path
from typing import Any

import folder_paths
import numpy as np
import piexif
import piexif.helper
import torch
from PIL import Image
from PIL.PngImagePlugin import PngInfo


class SaveImageToFolder:
    """
    Save ComfyUI images to a supplied folder, or to ComfyUI's normal output
    folder when no output folder is connected.

    Metadata compatibility:

    - PNG:
        Stores AUTOMATIC1111-style generation text in the PNG text chunk
        named "parameters".

    - JPEG / WebP:
        Stores the same generation text in EXIF UserComment using the same
        Unicode encoding used by AUTOMATIC1111.

    This allows AUTOMATIC1111's PNG Info tab to read both PNG and JPEG files.

    For the most accurate metadata, connect the final expanded positive and
    negative prompt strings to the optional positive_text and negative_text
    inputs.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "images": ("IMAGE",),
                "filename_prefix": (
                    "STRING",
                    {
                        "default": "Krea2",
                        "multiline": False,
                    },
                ),
                "format": (
                    ["jpg", "png", "webp"],
                    {
                        "default": "jpg",
                    },
                ),
                "quality": (
                    "INT",
                    {
                        "default": 95,
                        "min": 1,
                        "max": 100,
                        "step": 1,
                    },
                ),
                "include_date": (
                    "BOOLEAN",
                    {
                        "default": True,
                    },
                ),
                "include_time": (
                    "BOOLEAN",
                    {
                        "default": True,
                    },
                ),
                "include_counter": (
                    "BOOLEAN",
                    {
                        "default": True,
                    },
                ),
                "counter_digits": (
                    "INT",
                    {
                        "default": 5,
                        "min": 1,
                        "max": 10,
                        "step": 1,
                    },
                ),
                "save_metadata": (
                    "BOOLEAN",
                    {
                        "default": True,
                    },
                ),
            },
            "optional": {
                "output_folder": (
                    "STRING",
                    {
                        "default": "",
                        "multiline": False,
                        "forceInput": True,
                    },
                ),
                "positive_text": (
                    "STRING",
                    {
                        "default": "",
                        "multiline": True,
                        "forceInput": True,
                    },
                ),
                "negative_text": (
                    "STRING",
                    {
                        "default": "",
                        "multiline": True,
                        "forceInput": True,
                    },
                ),

                # Connect the central Master Seed output here. When supplied,
                # this value is written to A1111 metadata instead of trying
                # to infer the seed from the KSampler node.
                "generation_seed": (
                    "INT",
                    {
                        "default": 0,
                        "min": 0,
                        "max": 0xFFFFFFFFFFFFFFFF,
                        "forceInput": True,
                    },
                ),
            },
            "hidden": {
                "prompt": "PROMPT",
                "extra_pnginfo": "EXTRA_PNGINFO",
            },
        }

    RETURN_TYPES = ()
    FUNCTION = "save_images"
    OUTPUT_NODE = True
    CATEGORY = "Dominic/Image"

    @staticmethod
    def _sanitize_filename_component(value: str) -> str:
        value = str(value)
        value = re.sub(r'[<>:"/\\|?*\x00-\x1F]', "_", value)
        value = re.sub(r"\s+", " ", value)
        value = value.strip().rstrip(". ")

        if not value:
            return "image"

        reserved_names = {
            "CON", "PRN", "AUX", "NUL",
            *(f"COM{i}" for i in range(1, 10)),
            *(f"LPT{i}" for i in range(1, 10)),
        }

        base_name = value.split(".", 1)[0].upper()
        if base_name in reserved_names:
            value = "_" + value

        return value

    @staticmethod
    def _tensor_to_pil(image: torch.Tensor | np.ndarray) -> Image.Image:
        if isinstance(image, torch.Tensor):
            image = image.detach().cpu().numpy()

        image = np.asarray(image)

        if image.ndim == 4:
            image = image[0]

        image = np.clip(image * 255.0, 0, 255).astype(np.uint8)

        if image.ndim == 2:
            return Image.fromarray(image, mode="L").convert("RGB")

        if image.shape[-1] == 4:
            return Image.fromarray(image, mode="RGBA")

        return Image.fromarray(image, mode="RGB")

    @staticmethod
    def _next_counter(folder: Path, extension: str, counter_digits: int) -> int:
        pattern = re.compile(
            rf"_(\d{{{counter_digits}}})\.{re.escape(extension)}$",
            re.IGNORECASE,
        )

        highest = 0

        try:
            entries = folder.iterdir()
        except OSError as exc:
            raise RuntimeError(f"Could not inspect output folder: {folder}") from exc

        for path in entries:
            if not path.is_file():
                continue

            match = pattern.search(path.name)
            if match:
                highest = max(highest, int(match.group(1)))

        return highest + 1

    @staticmethod
    def _collision_safe_path(folder: Path, stem: str, extension: str) -> Path:
        candidate = folder / f"{stem}.{extension}"

        if not candidate.exists():
            return candidate

        collision_counter = 1

        while True:
            candidate = folder / f"{stem}_duplicate_{collision_counter:03d}.{extension}"

            if not candidate.exists():
                return candidate

            collision_counter += 1

    @staticmethod
    def _iter_prompt_nodes(prompt: Any):
        if not isinstance(prompt, dict):
            return

        for node_id, node in prompt.items():
            if isinstance(node, dict):
                yield str(node_id), node

    @classmethod
    def _find_sampler_inputs(cls, prompt: Any) -> dict[str, Any]:
        candidates: list[tuple[int, dict[str, Any]]] = []
        sampler_types = {
            "KSampler",
            "KSamplerAdvanced",
            "SamplerCustom",
            "SamplerCustomAdvanced",
        }

        for node_id, node in cls._iter_prompt_nodes(prompt) or []:
            class_type = str(node.get("class_type", ""))

            if class_type not in sampler_types:
                continue

            inputs = node.get("inputs", {})

            try:
                sort_id = int(node_id)
            except ValueError:
                sort_id = -1

            if isinstance(inputs, dict):
                candidates.append((sort_id, inputs))

        if not candidates:
            return {}

        candidates.sort(key=lambda item: item[0])
        return candidates[-1][1]

    @classmethod
    def _find_model_name(cls, prompt: Any) -> str | None:
        preferred_keys = (
            "ckpt_name",
            "unet_name",
            "model_name",
            "diffusion_model",
        )

        found: list[tuple[int, str]] = []

        for node_id, node in cls._iter_prompt_nodes(prompt) or []:
            inputs = node.get("inputs", {})

            if not isinstance(inputs, dict):
                continue

            try:
                sort_id = int(node_id)
            except ValueError:
                sort_id = -1

            for key in preferred_keys:
                value = inputs.get(key)

                if isinstance(value, str) and value.strip():
                    found.append((sort_id, Path(value).name))
                    break

        if not found:
            return None

        found.sort(key=lambda item: item[0])
        return found[-1][1]

    @classmethod
    def _find_vae_name(cls, prompt: Any) -> str | None:
        found: list[tuple[int, str]] = []

        for node_id, node in cls._iter_prompt_nodes(prompt) or []:
            inputs = node.get("inputs", {})

            if not isinstance(inputs, dict):
                continue

            value = inputs.get("vae_name")

            if not isinstance(value, str) or not value.strip():
                continue

            try:
                sort_id = int(node_id)
            except ValueError:
                sort_id = -1

            found.append((sort_id, Path(value).name))

        if not found:
            return None

        found.sort(key=lambda item: item[0])
        return found[-1][1]

    @staticmethod
    def _normalise_sampler_name(value: Any) -> str | None:
        if value is None:
            return None

        text = str(value).strip()

        if not text:
            return None

        known_names = {
            "euler": "Euler",
            "euler_ancestral": "Euler a",
            "heun": "Heun",
            "dpm_2": "DPM2",
            "dpm_2_ancestral": "DPM2 a",
            "lms": "LMS",
            "dpmpp_2s_ancestral": "DPM++ 2S a",
            "dpmpp_2m": "DPM++ 2M",
            "dpmpp_sde": "DPM++ SDE",
            "dpmpp_2m_sde": "DPM++ 2M SDE",
            "ddim": "DDIM",
            "uni_pc": "UniPC",
        }

        return known_names.get(text.lower(), text)

    @classmethod
    def _build_a1111_infotext(
        cls,
        positive_text: str | None,
        negative_text: str | None,
        prompt: Any,
        width: int,
        height: int,
        generation_seed: int | None = None,
    ) -> str:
        positive = str(positive_text or "").strip()
        negative = str(negative_text or "").strip()

        sampler_inputs = cls._find_sampler_inputs(prompt)

        steps = sampler_inputs.get("steps")
        cfg = sampler_inputs.get("cfg")
        # Prefer the explicitly connected global Master Seed. This is the
        # actual seed controlling the whole generation and may differ from
        # whatever value is stored inside the KSampler workflow node.
        seed = (
            int(generation_seed)
            if generation_seed is not None
            else sampler_inputs.get("seed")
        )
        denoise = sampler_inputs.get("denoise")
        sampler = cls._normalise_sampler_name(sampler_inputs.get("sampler_name"))
        scheduler = sampler_inputs.get("scheduler")

        parameter_parts: list[str] = []

        if steps is not None:
            parameter_parts.append(f"Steps: {steps}")

        if sampler:
            parameter_parts.append(f"Sampler: {sampler}")

        if scheduler is not None and str(scheduler).strip():
            parameter_parts.append(f"Schedule type: {str(scheduler).strip()}")

        if cfg is not None:
            parameter_parts.append(f"CFG scale: {cfg}")

        if seed is not None:
            parameter_parts.append(f"Seed: {seed}")

        parameter_parts.append(f"Size: {width}x{height}")

        model_name = cls._find_model_name(prompt)
        if model_name:
            parameter_parts.append(f"Model: {model_name}")

        vae_name = cls._find_vae_name(prompt)
        if vae_name:
            parameter_parts.append(f"VAE: {vae_name}")

        if denoise is not None:
            parameter_parts.append(f"Denoising strength: {denoise}")

        lines: list[str] = []

        if positive:
            lines.append(positive)

        if negative:
            lines.append(f"Negative prompt: {negative}")

        lines.append(", ".join(parameter_parts))

        return "\n".join(lines)

    @staticmethod
    def _save_png(image: Image.Image, path: Path, infotext: str | None) -> None:
        pnginfo = None

        if infotext is not None:
            pnginfo = PngInfo()
            pnginfo.add_text("parameters", infotext)

        image.save(
            path,
            format="PNG",
            pnginfo=pnginfo,
            optimize=True,
        )

    @staticmethod
    def _save_jpeg(
        image: Image.Image,
        path: Path,
        quality: int,
        infotext: str | None,
    ) -> None:
        if image.mode not in ("RGB", "L"):
            image = image.convert("RGB")

        image.save(
            path,
            format="JPEG",
            quality=quality,
            optimize=True,
            subsampling=0,
        )

        if infotext is not None:
            exif_bytes = piexif.dump(
                {
                    "Exif": {
                        piexif.ExifIFD.UserComment:
                            piexif.helper.UserComment.dump(
                                infotext,
                                encoding="unicode",
                            ),
                    },
                }
            )

            piexif.insert(exif_bytes, str(path))

    @staticmethod
    def _save_webp(
        image: Image.Image,
        path: Path,
        quality: int,
        infotext: str | None,
    ) -> None:
        if image.mode not in ("RGB", "RGBA"):
            image = image.convert("RGB")

        image.save(
            path,
            format="WEBP",
            quality=quality,
            method=6,
        )

        if infotext is not None:
            exif_bytes = piexif.dump(
                {
                    "Exif": {
                        piexif.ExifIFD.UserComment:
                            piexif.helper.UserComment.dump(
                                infotext,
                                encoding="unicode",
                            ),
                    },
                }
            )

            piexif.insert(exif_bytes, str(path))

    def save_images(
        self,
        images,
        filename_prefix,
        format,
        quality,
        include_date,
        include_time,
        include_counter,
        counter_digits,
        save_metadata,
        output_folder=None,
        positive_text=None,
        negative_text=None,
        generation_seed=None,
        prompt=None,
        extra_pnginfo=None,
    ):
        if output_folder is not None and str(output_folder).strip():
            folder = Path(str(output_folder)).expanduser().resolve()
        else:
            folder = Path(folder_paths.get_output_directory()).expanduser().resolve()

        try:
            folder.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise RuntimeError(f"Could not create output folder: {folder}") from exc

        if not folder.is_dir():
            raise RuntimeError(f"Output path is not a directory: {folder}")

        extension = str(format).lower()

        if extension == "jpeg":
            extension = "jpg"

        prefix = self._sanitize_filename_component(filename_prefix)
        now = datetime.now()
        common_parts = [prefix]

        if include_date:
            common_parts.append(now.strftime("%Y%m%d"))

        if include_time:
            common_parts.append(now.strftime("%H%M%S"))

        first_counter = None

        if include_counter:
            first_counter = self._next_counter(
                folder=folder,
                extension=extension,
                counter_digits=counter_digits,
            )

        saved_paths: list[str] = []

        for image_index, image_tensor in enumerate(images):
            filename_parts = list(common_parts)

            if include_counter and first_counter is not None:
                counter_value = first_counter + image_index
                filename_parts.append(f"{counter_value:0{counter_digits}d}")
            elif len(images) > 1:
                filename_parts.append(f"{image_index:03d}")

            stem = "_".join(filename_parts)

            full_path = self._collision_safe_path(
                folder=folder,
                stem=stem,
                extension=extension,
            )

            image = self._tensor_to_pil(image_tensor)
            infotext = None

            if save_metadata:
                infotext = self._build_a1111_infotext(
                    positive_text=positive_text,
                    negative_text=negative_text,
                    prompt=prompt,
                    width=image.width,
                    height=image.height,
                    generation_seed=generation_seed,
                )

            if extension == "jpg":
                self._save_jpeg(
                    image=image,
                    path=full_path,
                    quality=quality,
                    infotext=infotext,
                )
            elif extension == "png":
                self._save_png(
                    image=image,
                    path=full_path,
                    infotext=infotext,
                )
            elif extension == "webp":
                self._save_webp(
                    image=image,
                    path=full_path,
                    quality=quality,
                    infotext=infotext,
                )
            else:
                raise RuntimeError(f"Unsupported image format: {extension}")

            saved_paths.append(str(full_path))
            print(f"[Save Image To Folder] Saved: {full_path}")

            if infotext is not None:
                print(
                    "[Save Image To Folder] Embedded "
                    "AUTOMATIC1111-compatible metadata."
                )

        return {
            "ui": {
                "text": saved_paths,
            }
        }


NODE_CLASS_MAPPINGS = {
    "SaveImageToFolder": SaveImageToFolder,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "SaveImageToFolder": "Save Image To Folder",
}
